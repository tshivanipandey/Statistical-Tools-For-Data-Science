# Statistics For Data Science practicals

## 1. Data Handling

## 2. Data Visualization

## 3. Advance Data Visualization

## 4. Probability

## 5. Discrete Distribution

## 6. Continuous Distribution

## 7. Discriptive Statistics

## 8. Hypothesis Testing